#! /bin/bash

greeting="heyy, welcome"
user=$(whoami)
date=$(date +%F)

echo "$greeting $user! Today is $date"
echo "Your bash shrll version is : $BASH_VERSION.!"
