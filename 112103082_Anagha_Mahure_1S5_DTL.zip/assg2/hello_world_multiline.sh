echo This is DTL Assignment.
echo Hello, I am Anagha.
echo This is multiline file.
