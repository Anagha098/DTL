# !/bin/bash -xv

echo ${1} ${2} ${9} ${5}
