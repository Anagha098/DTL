#! /bin/bash

name="Anagha Mahure"
echo My name is ${name}.
