#! /bin/bash

user=$(whoami)
input=/home/${user}
output=/tmp/${user}_home_$(date +%Y-%m-%d_%H%M%S).tar.gz

tar -cvf $output $input

echo "$input backup is complete. Details of backup are :"
ls -l $output
