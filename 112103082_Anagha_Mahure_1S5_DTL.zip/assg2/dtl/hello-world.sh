# !/bin/bash -xv

# This is DTL Assignment.

echo "Hello, I am Anagha."
