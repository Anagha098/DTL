#! /bin/bash

echo
echo $* Represents all arguments as single string
echo
echo $@ Represents all arguments as an array rather than a string
echo 
echo $# Total number of positional arguments
echo 
echo $- Current flag position
echo
echo $$ PID of shell
echo
echo $! PDI of last executed background command
echo 
echo $0  NAme of the shell or shell script
echo
echo $_ Final argument of last executed foreground command
echo
echo $? Represents exit status of the last executed foreground command
echo
