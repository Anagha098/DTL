#! /bin/bash

a=19
if((a==30))
then echo YES;
else
echo NO;
fi
